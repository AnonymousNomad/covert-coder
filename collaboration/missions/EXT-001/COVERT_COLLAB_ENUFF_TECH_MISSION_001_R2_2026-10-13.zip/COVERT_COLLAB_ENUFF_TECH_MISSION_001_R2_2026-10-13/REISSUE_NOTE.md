# Mission 001 — R2 distribution note

This is a packaging-only reissue of Mission 001.

The first GitHub-hosted ZIP was reported with a SHA-256 that did not match the canonical package and `unzip` reported that it was not a valid ZIP archive. R2 was rebuilt from the canonical validated Mission 001 contents.

Mission scope, collaborator, repository, source lock, and operational boundaries are unchanged.

Before extraction, verify the outer ZIP size and SHA-256 supplied by the owner. After extraction, run `bash scripts/verify-package.sh` (or `bash scripts/start.sh`, which performs package verification as part of startup).
