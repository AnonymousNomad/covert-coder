#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, os, socket, sys, zipfile
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
host = socket.gethostname().split(".")[0]
evidence = root / "evidence" / host
outdir = root / "returns"
outdir.mkdir(parents=True, exist_ok=True)

required = [
    "environment.txt",
    "gpu.txt",
    "gpu-topology.txt",
    "tool-versions.txt",
    "source-fingerprint.txt",
    "package-verification.txt",
    "plugin-loaded.json",
    "model-lock.json",
]
missing = [name for name in required if not (evidence / name).exists()]

source_ok = False
source_file = evidence / "source-fingerprint.txt"
if source_file.exists():
    source_ok = "head=1dd2b1729e470713156da821679a46c5583daac4" in source_file.read_text(errors="replace")
    source_ok = source_ok and "status_begin\nstatus_end" in source_file.read_text(errors="replace")

model_ok = False
model_file = evidence / "model-lock.json"
if model_file.exists():
    try:
        d = json.loads(model_file.read_text())
        model_ok = "deepseek" in f"{d.get('providerID','')}/{d.get('id','')}".lower()
    except Exception:
        pass

package_ok = (root / "evidence" / "package-verification.txt").exists()

if missing:
    status = "PARTIAL"
elif not source_ok or not model_ok or not package_ok:
    status = "FAIL"
else:
    status = "PASS"

result = {
    "mission_id": "M001",
    "host": host,
    "status": status,
    "generated_at": datetime.now(timezone.utc).isoformat(),
    "source_sha_required": "1dd2b1729e470713156da821679a46c5583daac4",
    "source_ok": source_ok,
    "deepseek_model_lock_ok": model_ok,
    "package_verification_record_present": package_ok,
    "missing_required_evidence": missing,
}
(evidence / "mission-result.json").write_text(json.dumps(result, indent=2) + "\n")

index_lines = [f"{p.name}\t{p.stat().st_size}" for p in sorted(evidence.iterdir()) if p.is_file()]
(evidence / "evidence-index.txt").write_text("\n".join(index_lines) + "\n")

stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
out = outdir / f"COVERT_RETURN_M001_{host}_{stamp}.zip"
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(evidence.iterdir()):
        if p.is_file():
            z.write(p, arcname=p.name)

h = hashlib.sha256(out.read_bytes()).hexdigest()
print(f"RETURN_ZIP={out}")
print(f"RETURN_SHA256={h}")
print(f"MISSION_STATUS={status}")
sys.exit(0 if status == "PASS" else 2)
