#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="$(hostname -s 2>/dev/null || hostname)"
OUT="$ROOT/evidence/$HOST"
mkdir -p "$OUT"

run() {
  local label="$1"; shift
  {
    echo "===== $label ====="
    "$@"
    rc=$?
    echo "[exit=$rc]"
    echo
    return 0
  } 2>&1
}

{
  date -u +"UTC=%Y-%m-%dT%H:%M:%SZ"
  run hostname hostname
  run id id
  run uname uname -a
  if [ -r /etc/os-release ]; then
    echo "===== /etc/os-release ====="
    cat /etc/os-release
    echo
  fi
  run lscpu lscpu
  run memory free -h
  run root-filesystem df -h /
  if command -v getenforce >/dev/null 2>&1; then run selinux getenforce; else echo "===== selinux ====="; echo "getenforce unavailable"; echo; fi
} > "$OUT/environment.txt"

{
  for cmd in git node npm python3 gcc cmake nvcc podman docker opencode; do
    echo "===== $cmd ====="
    if command -v "$cmd" >/dev/null 2>&1; then
      case "$cmd" in
        python3) "$cmd" --version 2>&1 ;;
        *) "$cmd" --version 2>&1 ;;
      esac
    else
      echo "UNAVAILABLE"
    fi
    echo
  done
} > "$OUT/tool-versions.txt"

if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi > "$OUT/gpu.txt" 2>&1 || true
  nvidia-smi topo -m > "$OUT/gpu-topology.txt" 2>&1 || true
else
  echo "nvidia-smi unavailable" > "$OUT/gpu.txt"
  echo "nvidia-smi unavailable" > "$OUT/gpu-topology.txt"
fi
