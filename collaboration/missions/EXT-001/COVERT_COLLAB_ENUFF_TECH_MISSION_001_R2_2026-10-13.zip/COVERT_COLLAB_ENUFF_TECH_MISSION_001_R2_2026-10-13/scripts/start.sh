#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
bash "$ROOT/scripts/bootstrap.sh"
exec bash "$ROOT/scripts/start-opencode.sh"
