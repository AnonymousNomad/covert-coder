#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="$(hostname -s 2>/dev/null || hostname)"
OUT="$ROOT/evidence/$HOST"
mkdir -p "$OUT"

status=0

bash "$ROOT/scripts/verify-package.sh" || status=1
bash "$ROOT/scripts/capture-environment.sh" || status=1
bash "$ROOT/scripts/capture-source.sh" || status=1

if [ ! -f "$OUT/plugin-loaded.json" ]; then
  echo "BLOCKED: harness plugin-load record missing" | tee "$OUT/plugin-check.txt"
  status=1
else
  echo "PASS: harness plugin-load record present" | tee "$OUT/plugin-check.txt"
fi

if [ ! -f "$OUT/model-lock.json" ]; then
  echo "BLOCKED: DeepSeek model-lock record missing" | tee "$OUT/model-check.txt"
  status=1
else
  echo "PASS: model-lock record present" | tee "$OUT/model-check.txt"
fi

python3 "$ROOT/scripts/build-return.py"
rc=$?
if [ "$rc" -ne 0 ]; then
  exit "$rc"
fi
exit "$status"
