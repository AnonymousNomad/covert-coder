#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE="1dd2b1729e470713156da821679a46c5583daac4"
REPO_URL="https://github.com/AnonymousNomad/covert-coder.git"
WORK_ROOT="${COVERT_COLLAB_WORK_ROOT:-$HOME/covert-collab/mission-001}"
REPO="$WORK_ROOT/covert-coder"
HOST="$(hostname -s 2>/dev/null || hostname)"
OUT="$ROOT/evidence/$HOST"

mkdir -p "$ROOT/evidence" "$ROOT/state" "$OUT"

if [ "$(id -u)" -eq 0 ]; then
  echo "BLOCKED: Mission 001 must run under a normal non-root development account."
  exit 10
fi

bash "$ROOT/scripts/verify-package.sh"

for cmd in git python3 opencode; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    if [ "$cmd" = "opencode" ]; then
      echo "BLOCKED: OpenCode V2 is not installed."
      echo "Official V2 installer:"
      echo "  curl -fsSL https://opencode.ai/v2/install | bash"
      exit 11
    fi
    echo "BLOCKED: required command missing: $cmd"
    exit 12
  fi
done

OCV="$(opencode --version 2>&1 | head -n1)"
MAJOR="$(printf '%s' "$OCV" | grep -oE '[0-9]+' | head -n1 || true)"
if [ -z "$MAJOR" ] || [ "$MAJOR" -lt 2 ]; then
  echo "BLOCKED: OpenCode V2 required; observed: $OCV"
  echo "Official V2 installer:"
  echo "  curl -fsSL https://opencode.ai/v2/install | bash"
  exit 13
fi

mkdir -p "$WORK_ROOT"
if [ ! -d "$REPO/.git" ]; then
  if [ -e "$REPO" ]; then
    echo "BLOCKED: $REPO exists but is not the dedicated Git repository."
    exit 14
  fi
  git clone "$REPO_URL" "$REPO"
else
  if [ -n "$(git -C "$REPO" status --porcelain)" ]; then
    echo "BLOCKED: dedicated collaborator checkout is dirty; refusing to reset."
    exit 15
  fi
fi

git -C "$REPO" fetch origin --prune
git -C "$REPO" cat-file -e "${BASE}^{commit}"
git -C "$REPO" checkout --detach "$BASE"

ACTUAL="$(git -C "$REPO" rev-parse HEAD)"
[ "$ACTUAL" = "$BASE" ] || { echo "FAIL: source SHA mismatch $ACTUAL"; exit 16; }
[ -z "$(git -C "$REPO" status --porcelain)" ] || { echo "FAIL: source checkout not clean"; exit 17; }

printf '%s\n' "$REPO" > "$ROOT/state/repo.path"

bash "$ROOT/scripts/capture-environment.sh"
bash "$ROOT/scripts/capture-source.sh"

echo "BOOTSTRAP_PASS"
echo "repo=$REPO"
echo "head=$ACTUAL"
echo "next: bash \"$ROOT/scripts/start-opencode.sh\""
