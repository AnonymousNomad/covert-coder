#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="$(hostname -s 2>/dev/null || hostname)"
OUT="$ROOT/evidence/$HOST"
REPO_PATH_FILE="$ROOT/state/repo.path"
[ -f "$REPO_PATH_FILE" ] || { echo "BLOCKED: state/repo.path missing"; exit 40; }
REPO="$(cat "$REPO_PATH_FILE")"
mkdir -p "$OUT"
{
  echo "repository=$REPO"
  echo "head=$(git -C "$REPO" rev-parse HEAD)"
  echo "branch=$(git -C "$REPO" branch --show-current || true)"
  echo "status_begin"
  git -C "$REPO" status --short
  echo "status_end"
  echo "remote_origin=$(git -C "$REPO" remote get-url origin | sed -E 's#(https?://)[^/@]+@#\1[redacted]@#')"
} > "$OUT/source-fingerprint.txt"
