#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="$(hostname -s 2>/dev/null || hostname)"
mkdir -p "$ROOT/evidence/$HOST"
cd "$ROOT"
if ! command -v sha256sum >/dev/null 2>&1; then
  echo "BLOCKED: sha256sum not available"
  exit 30
fi
sha256sum -c MANIFEST.sha256 | tee "$ROOT/evidence/package-verification.txt" "$ROOT/evidence/$HOST/package-verification.txt"
