#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[ -f "$ROOT/state/repo.path" ] || bash "$ROOT/scripts/bootstrap.sh"
REPO="$(cat "$ROOT/state/repo.path")"

export COVERT_CAPSULE_ROOT="$ROOT"
export OPENCODE_CONFIG="$ROOT/opencode-config/opencode.jsonc"
export OPENCODE_CONFIG_DIR="$ROOT/opencode-config"
export OPENCODE_DISABLE_PROJECT_CONFIG=1

cd "$REPO"
exec opencode
