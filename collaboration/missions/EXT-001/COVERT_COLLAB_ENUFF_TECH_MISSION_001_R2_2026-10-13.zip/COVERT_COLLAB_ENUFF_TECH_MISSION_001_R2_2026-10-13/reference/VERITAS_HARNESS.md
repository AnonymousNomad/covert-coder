# Veritas Harness — collaborator reference

Veritas is Covert's evidence layer for model-assisted development. A model may propose work, but a claim is not VERIFIED until deterministic checks support it.

For code-change missions, evidence normally includes the patch/diff, compile or typecheck, relevant tests and diff checks. Security/publish work requires a stronger evidence class and independent review.

Current repository gates include path-boundary, secret-scan, manifest validation, compile/check, tests and git-diff checks. A model verdict never overrides failed execution evidence.

For Mission 001 this capsule does not ask DeepSeek to approve itself. Acceptance is based on deterministic package, source, environment, model-lock and return-artifact checks.
