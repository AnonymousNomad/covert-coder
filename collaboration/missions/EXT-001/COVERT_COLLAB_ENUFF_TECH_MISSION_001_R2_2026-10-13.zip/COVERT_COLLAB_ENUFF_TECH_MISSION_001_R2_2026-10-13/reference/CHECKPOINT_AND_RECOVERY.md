# 06 — Interrupt and resume safely

**Trigger:** context pressure, domain change, unavailable dependency, resource stop, tool/session limit or shift end. **Why:** a compact checkpoint protects progress without carrying the entire chat.

1. Record timestamp and timezone, canonical repo/worktree, branch, HEAD and dirty files. Preserve uncommitted work; identify its purpose.
2. Record completed changes, relevant tests and counts, failures/skips/blocked checks, source/evidence paths and artifact hashes. Retain failed results.
3. Record accepted invariants, pending decisions, authorization references, owned running processes and cleanup state. Exclude secrets.
4. Write the exact next objective and first justified action, including expected result and unresolved hypothesis.
5. Set execution status honestly: active, blocked, paused or ended. Do not imply background activity after shutdown.
6. On resume refresh repository/process/resource truth before using the checkpoint. If it differs, reconcile the delta and invalidate stale evidence.

If the canonical checkpoint location is inaccessible, preserve a clearly labeled `UNSYNCED CHECKPOINT DRAFT` in an accessible owner-authorized private location. Include its creation time, last known source state and missing access. Do not describe the canonical project record as updated. If only temporary storage is available, explicitly record that durability is unproven. On reconnection, compare against the current canonical record, merge only still-valid facts and retain provenance; never overwrite newer state. Do not upload private source or credentials to obtain persistence.

**Exit:** another session can continue without rereading raw conversation or repeating completed work.
