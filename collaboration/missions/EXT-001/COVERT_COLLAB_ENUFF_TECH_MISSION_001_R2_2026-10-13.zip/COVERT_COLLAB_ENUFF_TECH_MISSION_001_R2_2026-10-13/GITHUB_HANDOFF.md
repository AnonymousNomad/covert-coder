# GitHub handoff protocol

Mission 001 does not modify Covert source, so no pull request is required.

Use one GitHub issue as the mission record:
- Title: `EXT-001 — enuff-tech EL9 / GPU collaborator qualification`
- Assignee: `enuff-tech`
- Attach this capsule ZIP to the issue.
- Record the capsule ZIP SHA-256 in the issue body.
- When finished, the collaborator attaches the two generated return ZIPs (one per host) to the same issue.

For future source-changing missions:
1. issue defines objective/scope/acceptance;
2. exact base SHA is recorded;
3. collaborator creates only the assigned `collab/enuff-tech/...` branch;
4. no direct push to protected production branch;
5. changes return through a pull request;
6. CI/evidence determines acceptance;
7. owner merges only after review.

OpenCode Console is the model/request-usage audit layer. GitHub issue/branch/PR history is the durable project-change record.
