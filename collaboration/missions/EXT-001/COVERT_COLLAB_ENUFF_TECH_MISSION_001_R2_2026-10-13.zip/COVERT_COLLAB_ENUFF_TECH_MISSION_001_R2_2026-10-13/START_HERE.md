# Covert Collaborator Capsule — Mission 001

Target collaborator: `enuff-tech`

This package is designed so you do not need a separate briefing. It carries the mission, Covert operating rules, a frozen harness scaffold, OpenCode configuration, deterministic preflight, evidence capture, and return packaging.

## Before starting

1. Accept the OpenCode workspace invitation from the Covert owner.
2. Use a normal non-root development account on the EL9 host.
3. Extract this ZIP somewhere under your home directory.
4. From the extracted package directory run:

```bash
bash scripts/start.sh
```

The script verifies the package, checks OpenCode/Git/Python, creates a dedicated Covert checkout pinned to the mission source SHA, captures the first environment baseline, then launches OpenCode with the capsule configuration.

If OpenCode V2 is not installed, the script stops and prints the official install command. Install V2 under your normal user account, then rerun `bash scripts/start.sh`.

## In OpenCode

If this machine has not been connected to the invited workspace yet, run:

```text
/connect
```

Choose the Covert workspace.

The owner has restricted the workspace model set. Select the available DeepSeek route if OpenCode asks.

Then run:

```text
/covert/start
```

The capsule plugin injects the Covert harness and mission on every primary model request. The first DeepSeek route used is pinned for the mission; later model changes are refused.

## Mission 001

This is a bootstrap and external-environment qualification mission. It DOES NOT authorize product source changes.

Run the package on both intended EL9 systems, one host at a time:
- RHEL 9.8 / 2x NVIDIA L40S
- Rocky Linux 9.8 / 2x NVIDIA H100 PCIe

Each host produces its own return ZIP. No continuous status messages are required.

## Hard boundaries

- Do not run the mission as root.
- Do not change NVIDIA drivers, CUDA, kernel, SELinux policy, firmware, or host security configuration.
- Do not install a model/runtime or change Covert source in Mission 001.
- Do not expose API keys, tokens, credentials, private keys, or shell history.
- Do not switch away from the pinned DeepSeek route after the mission begins.
- Stop on unexplained mutation, secret exposure, source mismatch, or package-integrity failure.

When the mission completes, the generated return ZIP path is printed. Attach that ZIP to the assigned GitHub issue.
