// Frozen Covert harness scaffold snapshot.
// Source: AnonymousNomad/covert-coder @ 1dd2b1729e470713156da821679a46c5583daac4
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const HARNESS_VERSION = '2.1.0';
export const CREDO_VERSION = '1.1.0';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CREDOCORE_PATH = path.join(ROOT, 'common', 'harness', 'credocore.md');

const FORMAT_CONTRACT = [
  'Output discipline: when asked for code, emit complete runnable code or SEARCH/REPLACE blocks with full paths - never prose wrapped around code.',
  "Never invent APIs, flags, or files; match the project's existing conventions.",
  'Keep changes minimal and reviewable; state how to verify them (test/build command).'
];

const TASK_SOP = {
  coding: [
    'Task SOP (coding): restate the goal in one line before solving.',
    'Prefer the smallest change that satisfies the request.',
    'Check edge cases and failure paths before declaring done.',
    'If a gate fails: stop, surface honestly, fix the cause, rerun.'
  ],
  planning: [
    'Task SOP (planning): produce numbered steps with acceptance criteria per step.',
    'Name risks with mitigations; flag unknowns as unknowns - do not paper over them.',
    'Sequence work so each step is independently verifiable.'
  ],
  utility: [
    'Task SOP (utility): answer directly first, then add only load-bearing detail.',
    'Cite where each fact came from this session, or label it unverified.'
  ]
};

function parseCredocore() {
  const text = readFileSync(CREDOCORE_PATH, 'utf8');
  const sections = {};
  const headerRe = /^# PART ([A-B])( FULL| COMPACT)? — .*/gm;
  let match;
  const marks = [];
  while ((match = headerRe.exec(text)) !== null) {
    const key = `PART ${match[1]}${match[2] ? ' ' + match[2].trim() : ''}`;
    marks.push({ key, start: headerRe.lastIndex });
  }
  for (let i = 0; i < marks.length; i++) {
    const end = i + 1 < marks.length ? text.indexOf(`# PART`, marks[i].start) : text.length;
    sections[marks[i].key] = text.slice(marks[i].start, end).trim();
  }
  return { sections, versionMatch: /credocore v([\d.]+)/.exec(text) };
}

let cache = null;
function credocore() {
  if (!cache) cache = parseCredocore();
  return cache;
}

function countInstructions(block) {
  return block.split('\n').filter(line => line.trim().length > 0 && !line.startsWith('#')).length;
}

export function composeScaffold({ effectiveContextTokens = 4096, taskFamily = 'coding' } = {}) {
  const { sections, versionMatch } = credocore();
  const strong = effectiveContextTokens >= 8192;
  const capLines = strong ? 150 : 24;
  const capBytes = strong ? 6144 : 640;

  if (!strong) {
    const micro = [
      'You are an expert software engineer working inside AIDE.',
      'Answer exactly what is asked - nothing else.',
      'When writing code: complete and runnable, no placeholders.'
    ];
    const system = `[AIDE harness ${HARNESS_VERSION} | tier:micro | ctx:${effectiveContextTokens}]\n${micro.join('\n')}`;
    return { system, tier: 'micro', bytes: Buffer.byteLength(system), version: HARNESS_VERSION, budget: { cap_lines: capLines, used_lines: 3, cap_bytes: capBytes, used_bytes: Buffer.byteLength(system) }, dropped: [] };
  }

  const A = sections['PART A'];
  const lensKey = 'PART B FULL';
  const sop = TASK_SOP[taskFamily] || TASK_SOP.coding;
  const dropped = [];
  let blocks = [
    { name: 'A', body: A },
    { name: 'FORMAT', body: FORMAT_CONTRACT.join('\n') },
    { name: lensKey, body: sections[lensKey] },
    { name: 'TASK_SOP', body: sop.join('\n') }
  ];

  const measure = bs => ({
    bytes: Buffer.byteLength(bs.map(b => b.body).join('\n')),
    lines: bs.reduce((sum, b) => sum + countInstructions(b.body), 0)
  });

  let m = measure(blocks);
  while ((m.bytes > capBytes || m.lines > capLines) && blocks.length > 1) {
    const victim = [...blocks].reverse().find(b => b.name !== 'A');
    dropped.push({ section: victim.name, reason: 'budget' });
    blocks = blocks.filter(b => b !== victim);
    m = measure(blocks);
  }

  const header = `[AIDE harness ${HARNESS_VERSION} | credo ${versionMatch ? versionMatch[1] : CREDO_VERSION} | tier:${strong ? 'full' : 'compact'} | ctx:${effectiveContextTokens}]`;
  const system = `${header}\n${blocks.map(b => b.body).join('\n\n')}`;
  return {
    system,
    tier: 'full',
    bytes: Buffer.byteLength(system),
    version: HARNESS_VERSION,
    budget: { cap_lines: capLines, used_lines: m.lines, cap_bytes: capBytes, used_bytes: m.bytes },
    dropped
  };
}
