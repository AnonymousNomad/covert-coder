Report only the current Mission 001 evidence state: package integrity, source lock, model lock, environment capture, GPU capture, return artifact, and any blocker. Do not infer missing evidence.
