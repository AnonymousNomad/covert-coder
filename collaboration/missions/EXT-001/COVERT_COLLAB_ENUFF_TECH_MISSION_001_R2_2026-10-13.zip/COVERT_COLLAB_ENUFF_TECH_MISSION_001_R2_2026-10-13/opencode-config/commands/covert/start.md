Execute the active Covert collaborator mission now.

Use the injected Covert harness and mission. First confirm the model/source/package invariants visible in the injected context, then run the packaged deterministic mission executor. Do not edit product source. Continue until the return ZIP exists or a mission stop condition is reached.
