---
name: covert-runtime-verification
description: Verify Covert capabilities through actual application and packaged runtime. Use for provider/BYOK, terminal, UI, persistence, authority, companion, and failure testing.
---

# Covert runtime verification

## Start with the claim

Record the capability, supported platform/runtime/provider scope, expected operator outcome, and required layers of proof. Discover commands from repository manifests, CI and existing SOPs. Do not invent stack-specific commands. Capture HEAD plus the dirty-diff hash if testing uncommitted changes.

Use test data and approved test credentials. Record only secret references; redact logs before committing or sharing. Never paste keys into shell arguments, transcripts, screenshots or fixtures. Check resource admission before starting servers or model loads, especially on NEURO-MIRROR.

## Select the relevant domain cases

- **Models/BYOK:** add, validate, retrieve, rotate, delete, revoked/missing/invalid keys, secure persistence and restart. Distinguish local credential deletion from provider-side revocation. Test discovery, model metadata, scoped/default selection and overrides, switching, privacy routing, offline behavior and unavailable models. Verify text, streams, cancellation, tool calls, structured output, reasoning behavior, vision and embeddings/reranking only where exposed. Cover context limits, accounting, malformed responses, timeout, quota/rate limit, bounded retry, duplicate side effects and explicit fallback. Test multiple supported providers/families using live calls; fixtures supplement but never replace live support claims. Record exact provider, model identifier, adapter version and evidence per capability.
- **Local models:** import/model pack integrity, GGUF metadata, hash mismatch, incompatible architecture, startup/load/unload, memory pressure, cancellation, qualification, role/project selection and packaged inference. Preserve installed/imported → available → qualified → selected → authorized → admitted distinctions.
- **Authority/execution:** denied and expired authority, admission failure, tampered inputs, replay, override attempts, tool permissions and cancellation. Prove denied work causes no execution side effect. Trace Resident → Orchestrator → Authority → Admission → runtime and back through evidence according to actual contracts.
- **UI:** enumerate each route and interactive control from source and runtime. Trace handler to subsystem. Test success, failure, busy, disabled, duplicate activation, keyboard, focus, accessibility and persistence. Compare visible state with runtime truth. Disabled/unavailable controls need an accurate explanation. Telemetry gauges must have real data, units, freshness and unavailable states.
- **Terminal/CLI/TUI:** real PTY and shell selection, cwd/env, authorization, stdout/stderr, ANSI, Unicode, resize, history, scroll, copy/paste, interrupts, exit codes, long commands, cancellation, concurrent sessions if supported, restart/restore, child-process cleanup and shutdown. Test supported operating systems and shells explicitly; one host proves only that host.
- **Persistence/files/Git:** create/open/save/reopen, restart, atomic writes, interrupted saves, migration, rollback, corruption, permissions, path traversal, symlinks and concurrent edits. Preserve user changes and existing worktrees. Exercise actual supported Git workflows, errors and conflicts in disposable repos.
- **Companion/integrations:** pairing/authentication, revocation, least privilege, protocol/version compatibility, offline/reconnect, duplicate/out-of-order events, idempotency, data ownership, sync conflicts and desktop/companion state agreement. Test only documented capabilities; inventory undefined requirements before building them.
- **Packaging:** reproducible build source, dependency/version pinning, artifact hash, first install/start, offline and connected operation as supported, upgrade/migration, recovery, uninstall/data retention, crash diagnostics and update integrity. Execute installation tests in a disposable clean environment. Record whether the environment is genuinely clean.

## Execute and classify

Establish baseline → reproduce → repair → run focused regression → exercise failure → run affected integration gates → verify packaged path where required. Record command, timestamps/timezone, environment, exit status, pass/fail/skip counts, expectation, observation and raw evidence path.

Keep mock/fixture, adapter integration, live provider, application E2E and packaged runtime results distinct. Missing credentials or hardware means BLOCKED/UNVERIFIED. A skip is not a pass. Mark N/A only with an architectural reason. Preserve failed runs alongside successful reruns.

## Stop and recover

Stop the affected test on unexplained data mutation, secret disclosure, runaway resource use or authority bypass. Capture redacted evidence, clean up only owned test resources, investigate root cause and restore test fixtures from their snapshot. Continue unrelated safe work when possible.

## Accept

Close only the exact tested scope. Link every verified assertion to current evidence. Revalidate after relevant integration changes. Do not infer release readiness from a successful build, rendered button, mocked provider, or developer-machine run.

## Research-backed checks

Map applicable controls to [OWASP ASVS](https://github.com/OWASP/ASVS) (5.0.0 shown on 2026-09-27 UTC) and [MASVS](https://mas.owasp.org/MASVS/) if the companion is mobile. Use versioned control references, not a claim of generic compliance.

Include [prompt-injection](https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html) cases in repository text, retrieved content and tool responses. Verify permission enforcement outside model-generated text. Observe actual network behavior for offline/privacy claims. Measure startup, memory/commit/VRAM, response/cancellation latency and cleanup with declared workloads and thresholds.
