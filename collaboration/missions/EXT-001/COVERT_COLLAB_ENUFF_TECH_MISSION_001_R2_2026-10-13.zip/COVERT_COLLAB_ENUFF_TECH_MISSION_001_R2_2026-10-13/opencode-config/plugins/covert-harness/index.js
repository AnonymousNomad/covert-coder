import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs"
import path from "node:path"
import os from "node:os"
import { composeScaffold } from "../../../harness/scaffold.mjs"

function mustRead(root, rel) {
  return readFileSync(path.join(root, rel), "utf8")
}

function safeWrite(file, value) {
  mkdirSync(path.dirname(file), { recursive: true })
  writeFileSync(file, JSON.stringify(value, null, 2) + "\n", "utf8")
}

export default {
  id: "covert.collaborator-harness",

  async setup(ctx) {
    const root = process.env.COVERT_CAPSULE_ROOT
    if (!root) throw new Error("COVERT_CAPSULE_ROOT is not set; launch with scripts/start.sh")

    const host = os.hostname().split(".")[0]
    const evidence = path.join(root, "evidence", host)
    mkdirSync(evidence, { recursive: true })

    safeWrite(path.join(evidence, "plugin-loaded.json"), {
      plugin: "covert.collaborator-harness",
      loaded_at: new Date().toISOString(),
      opencode_version: ctx.app?.version ?? "unknown",
      harness_version: "2.1.0",
      source_lock: "1dd2b1729e470713156da821679a46c5583daac4"
    })

    const lockFile = path.join(evidence, "model-lock.json")

    await ctx.session.hook("context", (event) => {
      const selected = {
        providerID: String(event.model?.providerID ?? ""),
        id: String(event.model?.id ?? ""),
        variant: event.model?.variant ?? null
      }
      const route = `${selected.providerID}/${selected.id}`.toLowerCase()

      if (!route.includes("deepseek")) {
        throw new Error(`Covert M001 model policy violation: expected DeepSeek route, got ${selected.providerID}/${selected.id}`)
      }

      if (existsSync(lockFile)) {
        const prior = JSON.parse(readFileSync(lockFile, "utf8"))
        if (prior.providerID !== selected.providerID || prior.id !== selected.id || (prior.variant ?? null) !== selected.variant) {
          throw new Error(`Covert M001 model route changed after pin: ${prior.providerID}/${prior.id} -> ${selected.providerID}/${selected.id}`)
        }
      } else {
        safeWrite(lockFile, {
          ...selected,
          pinned_at: new Date().toISOString(),
          policy: "first primary DeepSeek route is pinned for Mission 001"
        })
      }

      const scaffold = composeScaffold({ effectiveContextTokens: 8192, taskFamily: "coding" })
      const missionLayer = [
        mustRead(root, "COLLABORATOR_HARNESS.md"),
        mustRead(root, "MISSION.md"),
        mustRead(root, "RETURN_CONTRACT.md"),
        mustRead(root, "SOURCE_LOCK.json")
      ].join("\n\n---\n\n")

      event.system.push({
        type: "text",
        text: `${scaffold.system}\n\n[Covert collaborator capsule]\n${missionLayer}`
      })

      event.options.temperature = 0.1
      event.options.maxTokens = 6000
    })
  }
}
