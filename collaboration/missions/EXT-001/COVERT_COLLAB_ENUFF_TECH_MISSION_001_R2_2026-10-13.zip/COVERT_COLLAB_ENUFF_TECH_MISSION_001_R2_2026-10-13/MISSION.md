# M001 — Collaborator bootstrap + EL9/GPU baseline + harness certification

## Objective

Prove that the Covert collaboration lane is reproducible on the collaborator's EL9 systems and capture evidence we cannot obtain on the owner's GTX 1060 laptop.

This mission validates:
- package integrity;
- OpenCode V2 availability;
- managed DeepSeek route continuity;
- Covert harness injection;
- exact source checkout;
- non-root execution;
- EL9 system inventory;
- L40S/H100 GPU discovery and topology;
- source and environment fingerprint capture;
- deterministic return-artifact generation.

## Source lock

Repository:
`https://github.com/AnonymousNomad/covert-coder.git`

Accepted Workstation preparation base:
`1dd2b1729e470713156da821679a46c5583daac4`

This SHA is an accepted Workstation preparation checkpoint only. It is not product/release acceptance.

## Required execution

1. Confirm the capsule package passes `MANIFEST.sha256`.
2. Confirm the current user is NOT root.
3. Confirm OpenCode major version is 2 or newer.
4. Confirm the first primary model request is DeepSeek and allow the capsule to pin the exact provider/model route.
5. Confirm the dedicated repository checkout is clean and exactly at the source lock SHA.
6. Run the deterministic mission executor:

```bash
bash "$COVERT_CAPSULE_ROOT/scripts/execute-mission.sh"
```

7. Inspect the resulting evidence index. Do not convert UNKNOWN or unavailable tools into PASS.
8. Ensure a return ZIP was produced.
9. Repeat this package independently on the second EL9 host.

## No product mutation

Mission 001 is observational. Do not edit, commit, push, merge, reset, install project dependencies, alter drivers, alter CUDA, or change host security state.

## Acceptance

PASS on a host requires:
- package integrity PASS;
- non-root PASS;
- OpenCode V2 PASS;
- exact source SHA PASS;
- clean source PASS;
- harness plugin-load record present;
- model-lock record present and contains a DeepSeek route;
- environment/GPU evidence captured;
- return ZIP produced.

Anything else is PARTIAL or BLOCKED with the observed reason.
