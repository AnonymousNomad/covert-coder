# Return contract

The collaborator does not need to send continuous manual reports.

Each Mission 001 host returns one ZIP named approximately:

`COVERT_RETURN_M001_<hostname>_<UTC timestamp>.zip`

Required contents:
- `mission-result.json`
- `environment.txt`
- `gpu.txt`
- `gpu-topology.txt`
- `tool-versions.txt`
- `source-fingerprint.txt`
- `package-verification.txt`
- `plugin-loaded.json`
- `model-lock.json`
- `evidence-index.txt`

The return bundle MUST NOT include:
- API keys or provider credentials;
- SSH private keys;
- tokens/cookies;
- shell history;
- arbitrary home-directory contents;
- Covert source files;
- model weights.

Statuses:
- PASS = exact required evidence exists and condition was observed.
- PARTIAL = some required evidence exists, but required items are incomplete.
- BLOCKED = a dependency/access/environment condition prevented execution.
- FAIL = an observed required condition failed.

Do not convert errors or missing commands into PASS.
