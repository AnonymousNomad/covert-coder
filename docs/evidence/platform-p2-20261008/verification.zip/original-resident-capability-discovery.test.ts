import { test } from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { createProjectRegistry } from '../../node/src/services/project-registry.ts';
import { createProjectSeat } from '../../node/src/services/project-seat.ts';
import { createCipherLedger } from '../../node/src/services/cipher-ledger.ts';
import { createAppCatalog } from '../../node/src/services/app-catalog.ts';
import { createResidentCapabilityDiscovery } from '../../node/src/services/resident-capability-discovery.ts';
import { CIPHER_RESIDENT_ID } from '../../common/contracts/cipher-laptop.ts';
import { ResidentCapabilityQuery, ResidentCapabilityManifest } from '../../common/contracts/resident-capability.ts';
import type { ModelProviderRouteT, ModelExecutionAdapterT } from '../../common/contracts/model-access.ts';
import { ArchServer } from '../../node/src/server.ts';
import { buildRoutes } from '../../node/src/openapi.ts';
import { pairFixture } from './authority-fixture.ts';

const workerRoute = (overrides: Partial<ModelProviderRouteT> = {}): ModelProviderRouteT => ({ id: 'route:provider:model', model_id: 'model:worker', provider_id: 'provider', connection_id: 'connection', provider_model_id: 'worker', credential_source_id: 'credential:ref', execution_adapter_id: 'direct-http', model_support_state: 'VERIFIED', configured: true, health: 'HEALTHY', available: true, external_egress_required: true, operator_setup_required: false, setup_state: 'READY', selected_roles: ['IMPLEMENTATION'], ...overrides });
const adapter = (overrides: Partial<ModelExecutionAdapterT> = {}): ModelExecutionAdapterT => ({ id: 'direct-http', kind: 'DIRECT_HTTP', implementation: 'IMPLEMENTED', discovered: true, configured: true, available: true, canonical_default: false, ...overrides });
async function fixture(run: (f: { root: string; catalog: ReturnType<typeof createAppCatalog>; ledger: ReturnType<typeof createCipherLedger>; project: { project_id: string; checkout_id: string } }) => Promise<void>) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'covert-resident-p2-'));
  try {
    const seat = createProjectSeat(createProjectRegistry({ storageRoot: path.join(root, '.aide', 'platform-projects') }), root);
    const checkout = await seat.initialize();
    const ledger = createCipherLedger({ storageRoot: path.join(root, '.aide', 'cipher-laptop'), residentId: CIPHER_RESIDENT_ID });
    await ledger.status();
    await run({ root, catalog: createAppCatalog(seat, [{ method: 'GET', path: '/api/projects/current' }]), ledger, project: { project_id: checkout.project_id, checkout_id: checkout.checkout_id } });
  } finally { await fs.rm(root, { recursive: true, force: true }); }
}

test('Resident discovery preserves one canonical identity and truthfully refuses to invent a live seat', () => fixture(async ({ catalog, ledger, project }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger });
  const view = await discovery.read(project);
  assert.equal(view.resident_id, CIPHER_RESIDENT_ID);
  assert.equal(view.identity_state, 'OBSERVED');
  assert.equal(view.enrollment_state, 'GATED');
  assert.equal(view.principal_id, null);
  assert.equal(view.binding_generation, null);
  assert.equal(view.context_lease_ref, null);
  assert.deepEqual(view.project, project);
  assert.equal(view.grants.state, 'UNAVAILABLE');
  assert.deepEqual(view.grants.references, []);
  assert.equal(view.pending_operator_decisions.state, 'UNAVAILABLE');
  assert.ok(!('invoke' in discovery) && !('grant' in discovery) && !('enroll' in discovery));
}));

test('addressability is visible but never execution eligibility; missing owners remain unavailable', () => fixture(async ({ catalog, ledger, project }) => {
  const view = await createResidentCapabilityDiscovery({ catalog, ledger }).read(project);
  assert.equal(view.apps.length, 9);
  const bound = view.capabilities.find(c => c.id === 'project.identity.read')!;
  assert.equal(bound.route_state, 'ADDRESSABLE');
  assert.equal(bound.execution_state, 'GATED');
  assert.equal(view.capabilities.find(c => c.id === 'terminal.session.open')!.route_state, 'UNAVAILABLE');
  assert.equal(view.capabilities.find(c => c.id === 'terminal.session.open')!.reason, 'OWNER_ROUTE_UNAVAILABLE');
  assert.ok(view.capabilities.every(c => c.grant_state === 'NOT_EVALUATED' && c.admission_state === 'NOT_EVALUATED'));
}));

test('only canonical verified routes with implemented adapters become worker references, without credentials', () => fixture(async ({ catalog, ledger, project }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger, workerSnapshot: async () => ({ generated_at: new Date().toISOString(), routes: [workerRoute(), workerRoute({ id: 'unknown', model_support_state: 'UNKNOWN' }), workerRoute({ id: 'unsupported', model_support_state: 'UNSUPPORTED' }), workerRoute({ id: 'contract-only', execution_adapter_id: 'codex-cli' })], execution_adapters: [adapter(), adapter({ id: 'codex-cli', kind: 'CODEX_CLI', implementation: 'CONTRACT_ONLY' })] }) });
  const view = await discovery.read(project);
  assert.deepEqual(view.workers.references.map(w => w.route_id), ['route:provider:model']);
  assert.equal(view.workers.references[0]!.external_egress_required, true);
  assert.equal(view.workers.references[0]!.execution_state, 'GATED');
  assert.ok(!JSON.stringify(view).includes('credential:ref'));
  assert.equal(view.workers.source, 'ModelManagerView');
}));

test('failed worker owner and failed ledger are explicit and do not remove direct operator catalog access', () => fixture(async ({ catalog, project }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger: { status: async () => { throw new Error('offline'); } }, workerSnapshot: async () => { throw new Error('offline'); } });
  const view = await discovery.read(project);
  assert.equal(view.identity_state, 'UNAVAILABLE');
  assert.equal(view.workers.state, 'UNAVAILABLE');
  assert.equal((await catalog.read(project)).apps.length, 9);
}));

test('identity disagreement refuses discovery rather than laundering another Resident', () => fixture(async ({ catalog, ledger, project }) => {
  const status = await ledger.status();
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger: { status: async () => ({ ...status, resident_id: 'foreign.resident' }) } });
  await assert.rejects(() => discovery.read(project), /RESIDENT_IDENTITY_MISMATCH/);
}));

test('cross-project, stale generation and caller-grant fields are fail closed', () => fixture(async ({ catalog, ledger, project }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger });
  await assert.rejects(() => discovery.read({ ...project, checkout_id: randomUUID() }), /PROJECT_SCOPE_MISMATCH/);
  await assert.rejects(() => discovery.read({ ...project, catalog_generation: randomUUID() }), /CATALOG_GENERATION_CHANGED/);
  assert.equal(ResidentCapabilityQuery.safeParse({ ...project, principal_id: 'cipher', grants: ['*'] }).success, false);
}));

test('project mutation while owners are awaited invalidates discovery output', () => fixture(async ({ catalog, ledger, project, root }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger, workerSnapshot: async () => { await fs.writeFile(path.join(root, '.aide', 'platform-projects', 'catalog.json'), '{corrupt'); return { generated_at: new Date().toISOString(), routes: [], execution_adapters: [] }; } });
  await assert.rejects(() => discovery.read(project), /PROJECT_CATALOG_INVALID/);
}));

test('freshness uses explicit generation/expiry and bounded pull, with no fabricated event support', () => fixture(async ({ catalog, ledger, project }) => {
  const discovery = createResidentCapabilityDiscovery({ catalog, ledger });
  const view = await discovery.read(project);
  assert.equal(ResidentCapabilityManifest.safeParse(view).success, true);
  assert.equal(view.refresh.refresh_after_ms, 30000);
  assert.equal(view.refresh.change_events, 'GATED_NOT_IMPLEMENTED');
  assert.equal(Date.parse(view.valid_until) - Date.parse(view.observed_at), 30000);
  await discovery.assertFresh(view);
  await assert.rejects(() => createResidentCapabilityDiscovery({ catalog, ledger }).assertFresh(view), /DISCOVERY_GENERATION_CHANGED/);
  await assert.rejects(() => discovery.assertFresh({ ...view, observed_at: '2000-01-01T00:00:00.000Z', valid_until: '2000-01-01T00:00:30.000Z' }), /DISCOVERY_EXPIRED/);
}));

test('production Resident discovery route is authenticated, scoped and read-only when AI is absent', async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'covert-p2-http-'));
  const arch = new ArchServer(root, path.join(root, 'arch.log'));
  for (const route of await buildRoutes(root, 'test', { authority: arch.authority, events: arch.events })) arch.route(route);
  const server = await arch.listen(0), address = server.address(); assert.ok(address && typeof address === 'object');
  try {
    const owner = await pairFixture(arch, 'http://127.0.0.1:' + address.port), project = await arch.projects.current();
    const query = new URLSearchParams({ project_id: project.project_id, checkout_id: project.checkout_id }).toString();
    const response = await owner.request('/api/resident/capabilities?' + query);
    assert.equal(response.status, 200);
    const view = ResidentCapabilityManifest.parse((await response.json()).data);
    assert.equal(view.enrollment_state, 'GATED');
    assert.equal((await owner.request('/api/resident/capabilities')).status, 400);
    assert.equal((await owner.request('/api/resident/capabilities?' + query + '&principal_id=cipher')).status, 400);
    assert.equal((await owner.request('/api/resident/capabilities?' + query, { headers: { Authorization: 'Bearer invalid' } })).status, 403);
    assert.equal((await owner.request('/api/resident/capabilities', { method: 'POST', body: '{}' })).status, 404);
    assert.equal((await owner.request('/api/projects/current')).status, 200);
    assert.equal((await owner.request('/api/file?path=missing-file')).status, 404);
    assert.equal((await arch.cipherLedger.status()).unresolved_actions.length, 0);
  } finally { arch.events.close(); arch.authority.control.close(); await arch.logger.flush(); await new Promise<void>(resolve => server.close(() => resolve())); await fs.rm(root, { recursive: true, force: true }); }
});
