$ErrorActionPreference='Stop'
$r='E:\covert-platform-app-foundation-saul-20261008'
$s='C:\Users\Grey_\AppData\Local\Temp\covert-p2-20261008'
Set-Location $r
$env:NODE_OPTIONS='--max-old-space-size=1024'
$env:AIDE_CLOSED_LOOP='0';$env:AIDE_SELFIMPROVE_ROOT=$s;$env:TEMP=$s;$env:TMP=$s
function Gate([string]$phase){
 if((git rev-parse HEAD) -ne '4aa79faa393b1835c6eb654c96876d0796e2f460'){throw 'SOURCE_HEAD_CHANGED'}
 $o=Get-CimInstance Win32_OperatingSystem;$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 $p=[math]::Floor($o.FreePhysicalMemory/1024);$c=[math]::Floor(($m.CommitLimit-$m.CommittedBytes)/1MB)
 $v=[pscustomobject]@{utc=(Get-Date).ToUniversalTime().ToString('o');phase=$phase;physicalMiB=$p;freeCommitMiB=$c;open=($p -ge 3072 -and $c -gt 5120)}
 $v|ConvertTo-Json -Compress|Add-Content "$s\final-resource-gate.jsonl"
 Write-Output ($v|ConvertTo-Json -Compress)
 if(-not $v.open){throw 'RESOURCE_GATE_CLOSED'}
}
function Step([string]$name,[string[]]$nodeArgs){
 Gate $name
 $p=Start-Process (Get-Command node).Source -ArgumentList $nodeArgs -NoNewWindow -Wait -PassThru -RedirectStandardOutput "$s\$name.stdout.log" -RedirectStandardError "$s\$name.stderr.log"
 [pscustomobject]@{phase=$name;exit=$p.ExitCode;utc=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress|Add-Content "$s\final-results.jsonl"
 Write-Output "$name EXIT $($p.ExitCode)"
 if($p.ExitCode -ne 0){Get-Content "$s\$name.stdout.log","$s\$name.stderr.log" -Tail 80;throw ('FAILED_'+$name)}
}
try{
 Step 'p2-final-focused' @('--import','./scripts/http-close-shim.mjs','--test','--test-concurrency=1','tests/arch/platform-app-catalog.test.ts','tests/arch/resident-capability-discovery.test.ts')
 Step 'p2-final-node-types' @('node_modules/typescript/bin/tsc','-p','tsconfig.node.json','--noEmit')
 Step 'p2-final-browser-types' @('node_modules/typescript/bin/tsc','-p','browser/tsconfig.browser.json')
 Step 'p2-final-scoped-lint' @('node_modules/eslint/bin/eslint.js','common/contracts/platform-app.ts','common/contracts/resident-capability.ts','node/src/services/app-catalog.ts','node/src/services/resident-capability-discovery.ts','node/src/routes/resident-capabilities.ts','node/src/server.ts','node/src/openapi.ts','node/src/routes/projects.ts','node/src/routes/fs.ts','node/src/routes/terminal-sessions.ts','node/src/routes/cipher-laptop.ts','node/src/routes/models.ts','node/src/routes/connections.ts','node/src/routes/hardware.ts','node/src/routes/provenance.ts','node/src/routes/commands.ts','tests/arch/platform-app-catalog.test.ts','tests/arch/resident-capability-discovery.test.ts')
 Step 'p2-final-contracts' @('scripts/contracts.mjs')
 Step 'p2-final-regression' @('--import','./scripts/http-close-shim.mjs','--test','--test-concurrency=1','tests/arch/project-registry.test.ts','tests/arch/project-addressing.test.ts','tests/arch/shared-capability-seat.test.ts','tests/arch/route-authority-coverage.test.ts','tests/arch/openapi-drift.test.ts','tests/arch/terminal-session-routes.test.ts')
 Step 'p2-final-wsl-readiness' @('tests/unit/test-wsl-readiness.mjs')
 git diff --check;if($LASTEXITCODE -ne 0){throw 'DIFF_CHECK_FAILED'}
 Write-Output 'P2_VERIFICATION_COMPLETE'
}catch{Write-Output $_.Exception.Message;exit 1}
