$ErrorActionPreference='Stop'
$stage='C:\Users\Grey_\AppData\Local\Temp\covert-workstation-nightshift-20261008-0137'
$root=Get-CimInstance Win32_Process -Filter 'ProcessId=26484'
if($root.CommandLine -ne '"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --no-startup-window /prefetch:5'){throw 'EDGE_IDENTITY_CHANGED'}
$all=Get-CimInstance Win32_Process
$ids=@(26484)
do{$prior=$ids.Count; $ids+=@($all | Where-Object {$_.ParentProcessId -in $ids -and $_.ProcessId -notin $ids} | ForEach-Object {$_.ProcessId})}while($ids.Count -gt $prior)
$all | Where-Object {$_.ProcessId -in $ids} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine | ConvertTo-Json -Depth 3 | Set-Content "$stage\edge-stopped-owner.json"
$backup=Join-Path $stage 'preserved-edge-sessions'
foreach($profile in (Get-ChildItem "$env:LOCALAPPDATA\Microsoft\Edge\User Data" -Directory | Where-Object {$_.Name -eq 'Default' -or $_.Name -like 'Profile *'})){
 $source=Join-Path $profile.FullName 'Sessions'
 if(Test-Path $source){$target=Join-Path $backup $profile.Name; New-Item -ItemType Directory $target -Force|Out-Null
 foreach($file in (Get-ChildItem $source -File)){
  $reader=[IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
  try{$writer=[IO.File]::Create((Join-Path $target $file.Name));try{$reader.CopyTo($writer)}finally{$writer.Dispose()}}finally{$reader.Dispose()}
 }}
}
Get-ChildItem $backup -File -Recurse | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash | ConvertTo-Json | Set-Content "$stage\edge-session-preservation.json"
foreach($id in ($ids | Sort-Object -Descending)){ $current=Get-CimInstance Win32_Process -Filter "ProcessId=$id"; $before=$all | Where-Object {$_.ProcessId -eq $id};if($current -and $current.CreationDate -eq $before.CreationDate -and $current.CommandLine -eq $before.CommandLine){Stop-Process -Id $id -ErrorAction Stop}}
Write-Output 'PRESERVED_EDGE_TREE_STOPPED'
& "$stage\resume-part-a.ps1"
