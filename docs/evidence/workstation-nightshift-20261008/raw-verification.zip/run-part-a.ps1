$ErrorActionPreference='Stop'
$repo='E:\covert-workstation-integration-saul-20261006'
$stage='C:\Users\Grey_\AppData\Local\Temp\covert-workstation-nightshift-20261008-0137'
New-Item -ItemType Directory -Path $stage -Force | Out-Null
Set-Location $repo
$expected='edb9ba1fa3dd2cbce8a53e2776961117504f7ba9'
$env:TEMP=$stage;$env:TMP=$stage
$env:NODE_OPTIONS='--max-old-space-size=1024'
$env:AIDE_PLAYWRIGHT_CHANNEL='msedge'
$env:AIDE_CLOSED_LOOP='0';$env:AIDE_SELFIMPROVE_ROOT=$stage
function Assert-Source {
 if((git rev-parse HEAD) -ne $expected){throw 'SOURCE_HEAD_CHANGED'}
 $dirty=@(git status --porcelain)
 if(($dirty -join "`n") -ne " M browser/src/desktop/desktop.css`n M browser/src/panels/cipher-laptop.ts"){throw 'SOURCE_DIRTY_CHANGED'}
 foreach($pair in @(@('browser/src/desktop/desktop.css','CA06AAB5DB4924895933365D41D623CEBEABF27FD163503006365E196A68CAE3'),@('browser/src/panels/cipher-laptop.ts','2555C94388BA9E7DFFC48C8842598228C6D7E3000083DD50A0B9258FB9F06C41'))){if((Get-FileHash $pair[0] -Algorithm SHA256).Hash -ne $pair[1]){throw 'SOURCE_HASH_CHANGED'}}
}
function Gate([string]$phase){
 Assert-Source
 $o=Get-CimInstance Win32_OperatingSystem;$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
 $p=[math]::Floor($o.FreePhysicalMemory/1024);$c=[math]::Floor(($m.CommitLimit-$m.CommittedBytes)/1MB)
 $sample=[pscustomobject]@{utc=(Get-Date).ToUniversalTime().ToString('o');phase=$phase;physicalMiB=$p;freeCommitMiB=$c;open=($p -ge 3072 -and $c -gt 5120)}
 $sample|ConvertTo-Json -Compress|Add-Content -Encoding UTF8 "$stage\resource-gate.jsonl"
 Write-Output ($sample|ConvertTo-Json -Compress)
 if(-not $sample.open){throw 'RESOURCE_GATE_CLOSED'}
}
function Step([string]$name,[string[]]$nodeArgs){
 Gate $name
 $p=Start-Process (Get-Command node).Source -ArgumentList $nodeArgs -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$stage\$name.stdout.log" -RedirectStandardError "$stage\$name.stderr.log"
 [pscustomobject]@{phase=$name;exit=$p.ExitCode;utc=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress|Add-Content -Encoding UTF8 "$stage\results.jsonl"
 Write-Output "$name EXIT $($p.ExitCode)"
 if($p.ExitCode -ne 0){Get-Content "$stage\$name.stdout.log","$stage\$name.stderr.log" -Tail 70;throw ('FAILED_'+$name)}
}
try{
 Step 'focused' @('--test','tests/unit/test-cipher-laptop-panel.test.mjs','tests/unit/test-desktop-window-manager.test.mjs','tests/unit/test-desktop-launcher-view.test.mjs','tests/unit/test-terminal-panel-isolation.test.mjs','tests/unit/test-event-subscription-readiness.mjs')
 Step 'node-types' @('node_modules/typescript/bin/tsc','-p','tsconfig.node.json','--noEmit')
 Step 'browser-types' @('node_modules/typescript/bin/tsc','-p','browser/tsconfig.browser.json')
 Step 'scoped-lint' @('node_modules/eslint/bin/eslint.js','browser/src/panels/cipher-laptop.ts')
 Step 'production-build' @('node_modules/vite/bin/vite.js','build','--config','browser/vite.config.ts')
 Step 'workstation-journey' @('scripts/run-workstation-e2e.mjs','--max-failures=1','--output',"$stage\workstation-results")
 git diff --check;if($LASTEXITCODE -ne 0){throw 'DIFF_CHECK_FAILED'}
 Write-Output 'NIGHT_PART_A_RUNTIME_COMPLETE'
}catch{Write-Output $_.Exception.Message;exit 1}
